import torch
import torch.nn as nn

import torchvision.transforms as transforms

from PIL import Image
import matplotlib.pyplot as plt


## import target images(content image and style image)
def loader(content_img, style_img, size):
    content_img = Image.open(content_img)
    style_img = Image.open(style_img)
    content_img = convert_mode(content_img)
    style_img = convert_mode(style_img)
    
#用库transforms.Compose 定义复合函数transform
    transform = transforms.Compose([    # convert img into the data format
        transforms.Resize((size,size)),  # scale imported image
        transforms.ToTensor()  # the order is important 'Resize first and ToTensor'
    ])
#执行transform
    content_img_rsz = transform(content_img)
    style_img_rsz = transform(style_img)

    imshow(content_img_rsz, title = 'Content Image')
    imshow(style_img_rsz, title = 'Style Image')
    
#数据维度压缩torch.squeeze()、解压torch.unsqueeze()
#在数据的第一维增加一个维度
    content_img = content_img_rsz.unsqueeze(0) 
    style_img = style_img_rsz.unsqueeze(0)

    return content_img, style_img

def imshow(image, title = None,save_path = None):
    image = image.clone()
    image = image.squeeze(0)
    pil = transforms.ToPILImage()
    target_img_PIL = pil(image)
    plt.figure()
    plt.imshow(target_img_PIL)
    if title is not None:
        plt.title(title)
    if save_path is not None:
        target_img_PIL.save(save_path) 
    plt.pause(1)
    
# visualize resized target images
#def imshow(image, title = None):
#    image = image.clone()
    
#画图之前，在第一维减少一个维度
#    image = image.squeeze(0)
#    pil = transforms.ToPILImage()
#    target_img_PIL = pil(image)
#    plt.figure()
#    plt.imshow(target_img_PIL)
#    if title is not None:
#        plt.title(title)
#    plt.pause(1)

## gram_matrix for the 'style loss function'
def gram_matrix(input):

# b=batch size, c=channel size(number of feature maps)
# N=h*w=size of feature maps
    b, c, h, w = input.size()
    features = input.view(-1, h*w)  # -1表示这是一个不确定的数

# G=gram matrix
# normalize G by dividing by the number of element in G
    G = torch.mm(features, features.t())
    return G.div(b*c*h*w)


class Normalization(nn.Module):
    def __init__(self, mean, std):
        super(Normalization, self).__init__()
        
# 定义mean和std让他们能被 mean=[0.485, 0.456, 0.406] and std=[0.229, 0.224, 0.225]赋值 # .view the mean and std to make them [C x 1 x 1] so that they can
# directly work with image Tensor of shape [B x C x H x W].
  
        self.mean = torch.tensor(mean).view(-1, 1, 1)
        self.std = torch.tensor(std).view(-1, 1, 1)

# 定义normalization
    def forward(self, img):
        # normalize img
        return (img - self.mean) / self.std


## RGBA 2 RGB
def convert_mode(img):
    if img.mode == "RGB":
        return img
    elif img.mode == "RGBA":
        background = Image.new("RGB", img.size, (255, 255, 255))
        background.paste(img, mask=img.split()[3])
        background.save(img.filename, quality=100)
        converted_img = Image.open(img.filename)
        return converted_img

## check if images are successfully loaded
# loader("images/arizona.jpg", "images/snow.jpg", 128)